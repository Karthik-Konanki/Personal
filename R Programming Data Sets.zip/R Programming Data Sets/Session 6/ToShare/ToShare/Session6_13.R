iris
iris.num <- iris[,-5]
colSums(iris.num)
colMeans(iris.num)
apply(iris.num,2,min)
apply(iris.num,2,max)

#EXAMPLE 2

dim(UCBAdmissions)
rowSums(UCBAdmissions)
rowSums(UCBAdmissions,dim=2)

colSums(UCBAdmissions)
rowMeans(UCBAdmissions)
colMeans(UCBAdmissions)

