library(e1071)
engine.displ<-skewness(mtcars$disp) 
engine.displ

engine.cyl<-skewness(mtcars$cyl) 
engine.cyl
 
 #CLASSWORK
 
 #find the skewness of wt
library(e1071)
wtskew<- skewness(mtcars$wt)
wtskew
 
 