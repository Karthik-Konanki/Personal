#OUTLIER TREATMENT

 par(mfrow=c(1, 2)) # for side by side plotting
 x <- mtcars$mpg 
 x 
 plot(x)
 qnt <- quantile(x, probs=c(.25, .75), na.rm = T) 
 qnt
 caps <- quantile(x, probs=c(.05, .95), na.rm = T) 
 caps
 H <- 1.5 * IQR(x, na.rm = T) 
 H
 x[x < (qnt[1] - H)] <- caps[1] 
 x[x > (qnt[2] + H)] <- caps[2] 
 plot(x)
 
 