#Runtime of a chunk of code can be measured by taking the difference between the time of start and at the end of the code chunk.Simple yet flexible:

sleep_for_a_minute<- function(){Sys.sleep(60)}

start_time<-Sys.time()
sleep_for_a_minute()
end_time<- Sys.time()
end_time-start_time

