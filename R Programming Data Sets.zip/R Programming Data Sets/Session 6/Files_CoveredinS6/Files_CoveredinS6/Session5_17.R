
nchar("moe")
nchar("hello")
nchar("rahul")
s<-"Toverify"

nchar(s)
#to find the length of the vector
s1<- c("hello","hi","talk")

nchar(s1)



#Length function returns the length of the vector and not the lenght of the string
length("mfdf")
length(s)
length(c("fef","re"))


#to concatenate multiple strings , we make use of paste
v<- paste("everybody","likes","music")
length(v)
v

#to extract a substring
substr("statistics",1,2)
substr("statistics",-5,2)
ss<- c("Moe","Curry","Curly")
substr(ss,1,3)

cities <- c("New York,NY","Los Angeles, CA","Peoria, IL")
nchar(cities)
substr(cities,nchar(cities)-1,nchar(cities))



substr("helloefe",2,3)
substring("abcdef",1:6,1:6)

s<- "EndMemo.com R Language Tutorial"
substr(s,0,7)

# to convert  a string to upper case
s<- "lowercasetouppercase"

x<-toupper(s)
x

#to convert a string to lower case

x1<- "HELLOHOWAREYOU"

x12<- tolower(x1)
x12



#SPLITTING OF STRINGS BASED ON DELIMITERS
path<- "/home/mike/data/trials.csv"

strsplit(path,"/")

ba<-strsplit(path,"/")

ba

unlist(ba[1])

a<- "helloefe"

x1a<- strsplit(a,"o")

x1a

#substring replacement

xz<- sub("Tutorial","learning",s)
xz

#Use regular expression
str<- c("Regular","expression","examples of R language")
x<- grep("ex",str,value =F)
x


xr<-"line4322:He is now 25 years old,and weighs 130lbs";
xe<- grep("4322",xr,value =F)
xe

