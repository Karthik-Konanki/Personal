#SOME OTHER DATA TRANSFORMATIONS

#Creating a matrix from vector

vec1e<- c(43,44,45,46)
a<-matrix(vec,2,2)

#Creating a matrix from vector directly
afef<- matrix(c(1,2,3,3,4,56),3,2)
afef

#How do you transpose a matrix?
t(afef)

#How do you perform matrix multiplication?

afef%*%t(afef)

#How do you calculate inverse of a matrix

a<- matrix(c(1,2,3,4),2,2)
class(a)
solve(a)

#providing rownames for matrix

rownames(afef)= c("a","b","c")
colnames(afef) = c("c1","c2")
print(afef)

#Dropping a variable from a matrix

rwdf<- afef[c(1,2),,drop =FALSE]
rwdf

class(rwdf)


