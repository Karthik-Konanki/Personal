#Usage of rbind and colbind functions

obs1<- c(1,2,4,5)
obs2<- c(3,4,5,6)
obs3<- c(8,10,11,12)
obs4<- c(13,14,16,18)

dfrm3<- rbind(obs1,obs2,obs3,obs4)
dfrm3

dfrmc<- cbind(obs1,obs2,obs3,obs4)
dfrmc
class(dfrmc)
#Appending rows to a dataframe

library(MASS)
df<- MASS::Aids2
df
df1<- MASS::beav1
df2<- MASS::beav2
df1
df2
df3<- rbind(df1,df2)

df3
#rarely used structure: Pre-allocating spaces in a data.frame

m<- 10
dfspace<- data.frame(dosage =numeric(m),lab= factor(m,levels = c("NJ","IL","NY")),response = numeric(m))
dfspace

head(df3)
df3[3]
str(df3[3]) #data frame

df3[[3]]
str(df3[[3]]) #numeric
dat<-iris
dat
lss<-str(dat)

lst <- list(lss)
lst
