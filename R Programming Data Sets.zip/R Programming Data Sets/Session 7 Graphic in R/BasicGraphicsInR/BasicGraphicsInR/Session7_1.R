# Setup
#ggplot works only on dataframes and not on individual vectors
options(scipen=999)  # turn off scientific notation like 1e+06
library(ggplot2)
data("midwest", package = "ggplot2")  # load the data
# midwest <- read.csv("http://goo.gl/G1K41K") # alt source 

head(midwest)

# Init Ggplot 
#ggplot takes x and y axis,just creating a template
ggplot(midwest, aes(x=area, y=poptotal))  # area and poptotal are columns in 'midwest'

#Scatterplot

library(ggplot2)
#just creating a layer with x and y axis using ggplot;Every point represents a county.however, we need to identify and bring in basic components like plot title, meaningful  axis labels
ggplot(midwest, aes(x=area, y=poptotal)) + geom_point()

#lets add a smoothing layer with a linear model; It draws the line of best fit
library(ggplot2)
g <- ggplot(midwest, aes(x=area, y=poptotal)) + geom_point() + geom_smooth(method="lm")  # set se=FALSE to turnoff confidence bands
plot(g)
#the line of best fit is blue.If you mention ?geom_smooth to identify other methods associated with geom_smooth

dev.off() #if graphic code is busy,  if you are opened paint or any png, jpeg files, use dev.off() 


