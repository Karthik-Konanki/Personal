#1.Read the data from this csv file
#mention stringsAsFactors as False while readn the file

inputData <- read.csv('F://R//Data_files_excel//adult.csv',header=T,na.strings=c(""),stringsAsFactors = FALSE)
#3verify the top 6 rows of the input file                     
   head(inputData)
                        head(inputData)
                        head(inputData,10)#In case you have to verify 10 rows
                        #based on condition
                        #4.Create 2 data frames named input_ones and input_zeros;
                        #if above50K = 1,then assign those to input_ones otherwise to input_zeros
                        input_ones <- inputData[which(inputData$ABOVE50K == 1), ]
                        input_zeros <- inputData[which(inputData$ABOVE50K == 0), ]
                        input_ones1<-data.frame(subset(inputData, inputData$ABOVE50K== 1))
                        input_zeros2<-data.frame(subset(inputData, inputData$ABOVE50K== 0))
                        head(input_zeros)
                        set.seed(100)  # for repeatability of samples
                        #5.Create 4 more data frames as follows
                       # a) input_ones_training_rows
#b)input_zeros_training_rows
#c)test_ones
#d)test_zeros

input_ones_training_rows <- sample(1:nrow(input_ones), 0.7*nrow(input_ones))  # 1's for training
input_zeros_training_rows <- sample(1:nrow(input_zeros), 0.7*nrow(input_ones))  # 0's for training. Pick as many 0's as 1's

training_ones <- input_ones[input_ones_training_rows, ]  
training_zeros <- input_zeros[input_zeros_training_rows, ]
                        
trainingData <- rbind(training_ones, training_zeros)  # row bind the 1's and 0's 
                       
# Create Test Data
test_ones <- input_ones[-input_ones_training_rows, ]
test_zeros <- input_zeros[-input_zeros_training_rows, ]
testData <- rbind(test_ones, test_zeros)

#Find the dimension of the train_dataframe
dim(trainingData)
#9.Find the number of columns in the train_dataframe
ncol(trainingData)
#10.Verify the structure of the train dataframe
str(trainingData)
#11. Combine both the train and test data frames with a differentiating column at the end mentioning if its train or test
trainingData$addCol<-"train"
head(trainingData)
testData$addCol<-"test"
head(testData)
#12.Find the distinct occupations present in the train dataframe
#most preferred way to retrieve both the names and frequencies in the dataframe
table(trainingData$OCCUPATION)

#To retrieve only the names of distinct values
unique(trainingData$OCCUPATION) #IV
#Information Value -> derives the information rom every level of a categorical /numerical variable
#IV >0.8 -> IV is skewed dont use it
#IV between 0.3 to 0.79 ->its good and use Use UseMethod()
#IV <0.2 it has very less ifnroamtion use it at the cost of reduced model accuracies
#IV -> region ->NY,NJ,CA,TX,FL,MA ; derive inferences ; NY 0.7  + - ly correlated with target variable [ propenstiy to buy new product]
#strong IV ->lot of information

#build model -> regression ->NN,CNN ,LR -> region with NY is a significant factor towards Target



#13.Find the number of distinct train accounts who have done their masters,bachelors and doctorate
table(trainingData$EDUCATION)# Option1


#option2
nrow(trainingData[which(trainingData$EDUCATION == " Doctorate"), ])  
nrow(trainingData[which(trainingData$EDUCATION == " Bachelors"), ])
nrow(trainingData[which(trainingData$EDUCATION == " Masters"), ])

#option3
nrow(subset(trainingData,trainingData$EDUCATION==" Masters"))     
nrow(subset(trainingData,trainingData$EDUCATION==" Bachelors"))  
nrow(subset(trainingData,trainingData$EDUCATION==" Doctorate"))

#14.What is the profile of the oldest and the youngest person in the train_dataframe
max(trainingData$AGE) #90

subset(trainingData,trainingData$AGE==max(trainingData$AGE)) #option2 Subset

#option3
table(trainingData$AGE)
maxd <- trainingData[which(trainingData$AGE == max(trainingData$AGE)), ] #Extracts rows with the maximum age
mind <- trainingData[which(trainingData$AGE == min(trainingData$AGE)), ] #Extracts rows with the minimum age

# how many distinct workclasses are present in the train data frame 
table(trainingData$WORKCLASS)

unique(trainingData$WORKCLASS)
length(unique(trainingData$WORKCLASS,incomparables = FALSE))
#How many Prof_specialty earn more than 50K[above50K =1]
prof <- input_ones[which(input_ones$OCCUPATION == " Prof-specialty"), ]
nrow(prof)
#17. How many accounts with sales as occupation earn more than 50K [above50K =1]
 sales<-input_ones[which(input_ones$OCCUPATION == " Sales"),]
 nrow(sales)
 #Are there any duplicates in FNLWGT and if so, how many duplicates are present?
WithDup<- length(input_ones$FNLWGT)
uniqueOne<- length(unique(input_ones$FNLWGT))
dupl <- WithDup - uniqueOne
dupl
#duplicated
#What is the gender ratio in the train dataframe?
 unique(trainingData$SEX)
 male <- trainingData[which(trainingData$SEX ==" Male" ), ]
 nrow(male)
 female <- trainingData[which(trainingData$SEX ==" Female" ), ]
nrow(female)
nrow(male)/nrow(female)
#How many males are in "not-in_family" status
trainM<-subset(trainingData,trainingData$SEX==" Male")
unique(trainM$RELATIONSHIP)
notinF <-trainM[which(trainM$RELATIONSHIP == " Not-in-family"),]
nrow(notinF)
#what is the totalhrsperweek[sum] of white males?

trainWhi<-subset(trainingData,trainingData$RACE==" White")
sum(subset(trainWhi,trainWhi$SEX==" Male")$HOURSPERWEEK)
#what is the totalhrsperweek[sum] of white females?
sum(subset(trainWhi,trainWhi$SEX==" Female")$HOURSPERWEEK)
#usage of query functions in R
library(sqldf)
sqldf("SELECT COUNT(*) FROM trainingData where SEX ==' Female'")
trainingData$RACE1 <- as.character(trainingData$RACE)
 White <- trainingData[which(trainingData$RACE1 ==' White'),]
table(trainingData$RACE)
sqldf("SELECT SUM(HOURSPERWEEK) FROM White where SEX ==' Female'")
sqldf("SELECT SUM(HOURSPERWEEK) FROM White where SEX ==' Male'")
                    nonWhite <- trainingData[which(trainingData$RACE1 !=' White'),]
                    sqldf("SELECT SUM(HOURSPERWEEK) FROM nonWhite where SEX ==' Male'")
                   
                    #Is there any correlation between the earnings and hrsperweek?
                 
cor(trainingData$HOURSPERWEEK, trainingData$RACE,  method = "pearson", use = "complete.obs")
model<-glm (trainingData$ABOVE50K ~ trainingData$RACE+trainingData$HOURSPERWEEK , data = trainingData, family = binomial(link = "logit"))
summary(model) 
model<-glm (trainingData$ABOVE50K ~ trainingData$RACE+trainingData$HOURSPERWEEK , data = trainingData, family = binomial(link = "probit"))
summary(model)                       
                        