#Try installing Package cluster using CRAN REpository
#Try using install.packages() to install package MAc
# List all the packages that are installed in your system
# help.search("summary")

if (!require("madr")){install.packages("madr", dependencies = TRUE)}
#Documentation in R
#


