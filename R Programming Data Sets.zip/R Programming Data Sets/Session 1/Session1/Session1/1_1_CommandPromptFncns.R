#SIMPLE COMMAND PROMPT FUNCTIONS IN R

# To find the sum of two numbers in prompt

1 +2

#Subtraction of 2 numbers

4-2

#Multiplication of 2 numbers

5*10

#Division of 2 numbers

9/3

#Variable Assignment

y =45

y

#Variable assignment and basic arithmetic's

y = 45

y/7
#Comments in R

#Hello world

#Linear equation
y= 7 + (4*7) -(90*(76)) +98512

print(y)

source("D:\\Drive\\R\\R Programming Data Sets-20201114T054118Z-001\\R Programming Data Sets\\Session 1\\Session1\\Session1 061018\\1_1_CommandPromptFncns.R")
