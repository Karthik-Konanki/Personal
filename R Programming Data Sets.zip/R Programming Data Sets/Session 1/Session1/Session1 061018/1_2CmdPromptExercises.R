#SIMPLE COMMAND PROMPT FUNCTIONS IN R

# To find the sum of two numbers in prompt

1 +pi

1 + (pi+2)
#Subtraction of 2 numbers

4-(-2)
4- 2.5

#Multiplication of 2 numbers

5*10.2

#Division of 2 numbers

9/3.0
9.0/3.0

#Variable Assignment

y = 68+12

y

#Variable assignment and basic arithmetics

y = 852

y/2
#Comments in R

#Try if this works

#BODMAS

x1 = 98*657+487/3
x2 = (98*657+487)/3
x3 = 98*(657+487)/3
x1
x2
x3
