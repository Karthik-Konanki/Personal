#SIMPLE COMMAND PROMPT FUNCTIONS IN R

# To find the sum of two numbers in prompt

1 +2

#Subtraction of 2 numbers

4-2

#Multiplication of 2 numbers

5*10

#Division of 2 numbers

9/3

#Variable Assignment

y =45

y

#Variable assignment and basic arithmetics

y = 45

y/7
#Comments in R

#Hello world

#Linear equation
y= 7 + (4*7) -(90*(76)) +98512

print(y)

