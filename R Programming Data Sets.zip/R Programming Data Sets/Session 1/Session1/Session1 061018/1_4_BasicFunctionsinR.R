#Seeking help in R

#To know about a function in R, use help(func)
help(max)
help(mean) #to know about the function
args(max) #to give out only the arguments of the function
example(max) #gives examples on how to use the function
example(mean)

#What if you dont know the function's name
help.search("mean") # Pattern search

#Package search
help(package = "Hmisc")

#While install.packages is used to install a package, installed.packages() is to verify all installed packages
install.packages("ggplot2")
installed.packages()

vignette() #Package details and the package documentation details
vignette("hcl-colors") 

