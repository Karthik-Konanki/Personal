print("Chennai is hotter than Bangalore")
cat("Chennai is hotter than Bangalore")

#Print can understand and work on complex data types while cat function cant
x = print(matrix(c(2,3,4,5,6,7),3,2))
y = cat(matrix(c(2,3,4,5,6,7),3,2))

str(x)
str(y)

#CAT can combine multiple objects; print  cant combine multiple objects
print(list("Elon","Musk"))
test<- c(1,2,3,4)
cat("The value of this vectorial equation is ",test)

test<- c(1,2,3,4)
print("The value of this vectorial equation is",test)