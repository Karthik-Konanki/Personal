print("Extensive R Programming at 361DM")
cat("Extensive R programming at 361DM")

#Print can understand and work on complex data types while cat function cant
x = print(matrix(c(23,34,34,55,66,743),3,2))
y = cat(matrix(c(23,34,34,55,66,743),3,2))

#str is to give the structure of a variable
str(x)
str(y)

#CAT can combine multiple objects; print  cant combine multiple objects
print(list("hello","world"))


test<- c(1,2,3,4)
cat("I would like to print",test)

test<- c(1,2,3,4)
print("I would like to print",test)

print(test)
