#Download R from https://cran.r-project.org/



# https://cran.r-project.org/

#Path that would have all installed libraries
#C:\Users\meenag3\Documents\R\win-library

#manual install caret

#Option 1 :Tools->Install Packages ->Install to library->Install dependencies
#Option 2 
if(!require(MASS)){install.packages("MASS")}
library(MASS)#to load the packages
#Option 3 manual download
#best option to use CRAN download

save.image()




