#How do you bring in an additional dimension to the graph;

library(ggplot2)

gg <- ggplot(midwest, aes(x=area, y=poptotal)) + 
  geom_point(aes(col=state), size=3) +  # Set color to vary based on state categories.
  geom_smooth(method="lm", col="firebrick", size=2) + 
  coord_cartesian(xlim=c(0, 0.1), ylim=c(0, 1000000)) + 
  labs(title="Area Vs Population", subtitle="From midwest dataset", y="Population", x="Area", caption="Midwest Demographics")
plot(gg)

#if you don't want the legends to be present, then we can remove that 
gg + theme(legend.position="None") 

#If the color palette has to be changed, it can be done
gg + scale_colour_brewer(palette = "Set1")


#Similar to colors, if the color palettes are to be looked at, then they can be found at RcolorBrewer package

library(RColorBrewer)
head(brewer.pal.info, 10) 
?brewer.pal.info

