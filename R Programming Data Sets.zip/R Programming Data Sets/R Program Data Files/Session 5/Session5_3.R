#Syntax for FOR LOOP
#for( val in sequence) { statement}

#To find the number of even numbers in the given vector or list
x<- c(2,5,3,9,8,11,6)
count<- 0
for(valu in x){if (valu%%2 ==0) count = count +1}
print(count)

