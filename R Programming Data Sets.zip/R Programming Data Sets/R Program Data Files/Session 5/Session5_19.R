#EXERCISE
#Concatenate strings "Statistics","is","interesting"
vvv<-paste("Statistics","is","interesting")

#find the length of the concatenated string
length(vvv)

#Extract the first 2 characters from the string: "Inspiration"
substr("Inspiration",1,2)

#Extract the last 2 characters from the string: "Inspiration"
a<-"Inspiration"
substr("Inspiration",nchar(a)-3,nchar(a))

