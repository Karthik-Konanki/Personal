#RECURSIVE FUNCTIONS IN R
#Recursive function to find factorial
x<-4
recursive.factorial<- function(x) {
  if(x==0) return(1)
  else return(x*recursive.factorial(x-1))
}
recursive.factorial(4)

#Program to convert decimal number into binary number using recursive function
convert_to_binary <- function(n) {
  if(n > 1) {
    convert_to_binary(as.integer(n/2))
  }
  cat(n %% 2)
}

convert_to_binary(52)

