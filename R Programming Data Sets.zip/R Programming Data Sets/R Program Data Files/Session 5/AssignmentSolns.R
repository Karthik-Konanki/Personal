#ASSIGNMENT SOLUTIONS

#Convert this vector c(1,3,5,7,9,11,13,15,17) to a 3*3 matrix

mat1<- matrix(c(1,3,5,7,9,11,13,15,1),3,3)
str(mat1)

#Convert this vector c(1,3,5,7,9,11,13,15,17) to a data frame
df<-as.data.frame(c(1,3,5,7,9,11,13,15,17))

#Perform a transpose operation on this matrix
transp<- t(mat1)

#find the inverse of the matrix
invers =solve(mat1)
#Confirm if the inverse identified is correct or not
mat1%*%invers

solve(solve(mat1))

#Convert this vector c(1,2,3,4) and perform matrix multiplication on this?
a = matrix(c(1,2,3,4),2,2)
a%*%a

#Can you perform algebraic operations on
ab<- matrix(c(1,2,3,4),2,2)
ab+ab
ab-ab
ab*ab
ab/ab
#Can you convert the vector c(9,8,7,6) to a list
am<- c(9,8,7,6)
lstverify<-list(am)
lstver<- as.list(am)

#Convert the same list back to vector
vv<- unlist(lstver)
str(vv)

#Convert the vector to matrix and matrix back to vector
dfd<- matrix(c(1,2,3,4),2,2)
vvc<-as.vector(dfd)
str(vvc)

#Convert the vector c(1,3,5,7,9,11,13,15,17) to a data frame with 3 rows and 3 columns
dff<- matrix(c(1,3,5,7,9,11,13,15,17),3,3)
as.data.frame(dff)

#Convert matrix c(1,2,3,4) to a dataframe
as.data.frame(matrix(c(1,2,3,4)))

#Can you look at the first 12 observations of the mtcars dataset?
head(mtcars,12)

afd<- as.data.frame(mtcars)
library(sqldf)
afd

#select cyl,mpg,wt,qsec from mtcars, assign it to a variable and verify if its a dataframe?

fd<-data.frame(mtcars$cyl,mtcars$mpg,mtcars$wt,mtcars$qsec)

#Perform a mean on mtcars$wt
mean(mtcars$wt)

