#Addnl string operations

#Replacing a substring
#Use sub to replace the first instance of the substring
#SYNTAX

#sub(old,new,string)

#Use gsub to replace all instances of substring

#gsub(old,new,string)

s<- "Siva is the smart one.Siva is funny,too"
gsub("Siva","MSiva",s)

sub("Siva","MSiva",s)

#Special characters in string
locations<- c("CHN","HYD","MDU","CBE")
treatments <-c("T1","T2","T3")
outer(locations,treatments,paste,sep ="-")
