#SWITCH FUNCTIONS IN R
#The switch() function in R tests an expression against elements of a list. 
#If the value evaluated from the expression matches item from the list, the corresponding value is returned.

switch(2,"red","green","blue")
switch(1,"red","green","blue")

#If the numeric is out of range, then Null is returned
x <- switch(4,"red","green","blue")
x

#Values that match with name are retrieved and shared
switch("color", "color" = "red", "shape" = "square", "length" = 5)



