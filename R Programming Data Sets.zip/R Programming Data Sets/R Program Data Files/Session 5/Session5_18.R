#EXERCISE
#Concatenate strings "Statistics","is","interesting"


#find the length of the concatenated string


#Extract the first 2 characters from the string: "Inspiration"


#Extract the last 2 characters from the string: "Inspiration"


#how do you split the string based on pipeline char
vatr<- as.character("|name|age|gender|address|")

strsplit(vatr,"|")