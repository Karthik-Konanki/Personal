#STRING FUNCTIONS IN R


#To find the length of the string
nchar("moe")
nchar("hello")
nchar("rahul")

#to find the length of the vector
s<- c("hello","hi","talk")
nchar(s)

#Length function returns the length of the vector and not the lenght of the string
length("mfdf")
length(s)

#to concatenate multiple strings , we make use of paste
v<- paste("everybody","likes","music")
length(v)
v

#to extract a substring
substr("statistics",1,2)

ss<- c("Moe","Curry","Curly")
substr(ss,1,3)

cities <- c("New York,NY","Los Angeles, CA","Peoria, IL")
nchar(cities)
substr(cities,nchar(cities)-1,nchar(cities))

#SPLITTING OF STRINGS BASED ON DELIMITERS
path<- "/home/mike/data/trials.csv"

strsplit(path,"/")




