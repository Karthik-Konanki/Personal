#A repeat loop is used to iterate over a block of code multiple number of times.

#There is no condition check in repeat loop to exit the loop.

x <- 1
repeat {
  print(x)
  x = x+1
  if (x == 6){
    break
  }
}