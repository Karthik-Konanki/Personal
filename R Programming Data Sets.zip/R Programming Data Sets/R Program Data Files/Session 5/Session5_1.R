#Usage of simple conditionals
#usage of if and if-else-if and else if in R

#option1
x<- 5
if(x>0){print("Positive")}else {print("Negative")}

x<- -5
if(x>0){print("Positive")}else {print("negative")}

#option 3
y<- -5
x1<- if(y<0) -1 else 1
x1

#option 4
x<- 0
if(x<0){print("Negative number")} else if (x>0){print("positive number")}else print("Zero")

#usage of ifelse function
a<- c(1,3,5,8)
ifelse(a%%2 ==0,"even","odd")

