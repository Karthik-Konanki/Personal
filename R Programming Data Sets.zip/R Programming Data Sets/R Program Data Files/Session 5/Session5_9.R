#break and next statements
#A break statement is used inside a loop (repeat, for, while) to stop the iterations and flow the control outside of the loop.
#In a nested looping situation, where there is a loop inside another loop, this statement exits from the innermost loop that is being evaluated.

#if (test_expression) {
#  break
#}

x <- 1:5
for (val in x) {
  if (val == 3){
    break
  }
  print(val)
}


#NEXT's EXAMPLE

x <- 1:5
for (val in x) {
  if (val == 3){
    next
  }
  print(val)
}

