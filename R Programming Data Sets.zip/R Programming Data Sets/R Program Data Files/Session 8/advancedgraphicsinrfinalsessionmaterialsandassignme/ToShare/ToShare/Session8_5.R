#Bubble Plot 4Dimensions to plot
#What if you have more dimensions to be measured?
#While scatter plot provides us with the correlation/relationship between 2 variables,
#Bubble plot provides us with the relationship between more than 2 variables
#When there are 2 numeric variables, 1 categorical variable and 1 more numeric variable, then while x and y axis would take up both
#numeric variables, the categorical variable can be represented using color and  the other numeric variable in size

# load package and data
library(ggplot2)
data(mpg, package="ggplot2")
# mpg <- read.csv("http://goo.gl/uEeRGu")
head(mpg)

mpg_select <- mpg[mpg$manufacturer %in% c("audi", "ford", "honda", "hyundai"), ]

# Scatterplot
theme_set(theme_bw())  # pre-set the bw theme.
g <- ggplot(mpg_select, aes(displ, cty)) + 
  labs(subtitle="mpg: Displacement vs City Mileage",
       title="Bubble chart")

g + geom_jitter(aes(col=manufacturer, size=hwy)) + 
  geom_smooth(aes(col=manufacturer), method="lm", se=F)


#While the bubble chart differentiates between the range of displacement among different manufacturers, slope of line fit shows visual comparison between groups