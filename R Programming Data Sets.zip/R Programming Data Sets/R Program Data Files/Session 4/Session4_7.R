#Example

#create a matrix with values 1,2,3,4,5,6,7,8,9 and perform 
#sum of all rows
#product of all columns
#all values from matrix + 3

m1<- matrix(c(1,2,3,4,5,6,7,8,9),3,3)

apply(m1,1,sum)
apply(m1,2,prod)

vm<- apply(m1,c(1,2),function(x)x+3)

vm1<- apply(m1,2,function(x)is.matrix(x))

vm2<- apply(m1,2,is.vector)

