#Exercise

avc<- c(1,2,4,5,6)
avc
avm<- matrix(c(1,2,4,5,5,6),2,3)
avm
avl<- list(1,2,4,5)
avl
fdv<- data.frame(c(1,2,3,5),2,2)
fdv

#Convert vector to list
avc1<- as.list(avc)

#Convert list to vector
avlu <-unlist(avl)
str(avlu)

#convert vector to matrix
fdgm1<- as.matrix(avc)
str(fdgm1)

#convert vector to dataframe
vdmd<- as.data.frame(avc)
vdmd

#convert matrix to dataframe
mm<- as.data.frame(avm)
str(mm)
