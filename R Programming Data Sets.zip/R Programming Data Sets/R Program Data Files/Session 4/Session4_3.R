#Another data frame example to play around

MASS::Boston
head(Boston)
?Boston
ex1<- MASS::Boston
ex1[1] #data frame
ex1[[1]] #numeric


#Let us define all structures

vec<- c(1,2,4,5)
lst<- list(3,5,7)
fac<- factor(c("M","N","L"),c("M","N","L"))
mat<- matrix(c(1,2,3,4),2,2)
defferefe<- data.frame(c(1,2,3,4,5,6,7,8,9),3,3)

#Q1Convert vector to list
ver<- as.list(vec)
str(ver) #list
lstconv= list(vec)
str(lstconv)

#what is the difference between ver and lstconv

#Q2 Convert vector to matrix
matrre<- as.matrix(vec)
matrre

#Q3: Convert vector to dataframe
dffdfd<- data.frame(vec,2,2)
dffdfd

#Q4: list to dataframe

dfee<- as.data.frame(lst)
dfee

#Convert a matrix to vector

vxc<- as.vector(mat)
vxc

#matrix to list
ll<- as.list(mat)
ll

#matrix to dataframe
dfdfd<- as.data.frame(mat)
dfdfd

#dataframe to list
ll1<- as.list(dfdfd)
ll1

#dataframe to matrix

mmm<- as.matrix(dfdfd)
mmm



