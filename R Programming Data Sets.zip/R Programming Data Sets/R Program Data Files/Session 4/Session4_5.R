#Data transformations - Usage of apply functions in R

#Defining groups via factor
v<- c(1,2,3,4,6)
f<- factor(c("A","B","C","B","C"))

groups<-split(v,f)
groups

#alternate function
groups1<- unstack(data.frame(v,f))
groups1

#Example
#Usefulness of this function is that it allows to look at datasets by groups
library(MASS)
g<- split(Cars93$MPG.city,Cars93$Origin)

median(g[[1]])
median(g[[2]])
  
head(mtcars)
v<-split(mtcars$wt,mtcars$am)
median(v[[1]])
median(v[[2]])

#Using lapply functions on datasets
s1<- c(90,89,87,86,86,78,68,60,55)
s2<- c(90,99,97,96,54,35,24,77)
s3<- c(67,65,56,86,95)
s4<-c(90,99,80)

scores<-list(s1,s2,s3,s4)
lapply(scores,length) # applies the mentioned function to every element of the dataset and returns a list
sapply(scores,length) # applies the mentioned functon to every element of the dataset and returns a vector/simplified datstructure


sapply(scores,mean)
lapply(scores,sd)

sapply(scores,range) # if the function returns a vector, sapply returns a matrix

#sapply can be used for simple functions.When we use complex datatypes, it is better to use lapply

#example : t-test on the scores
tetsts<-lapply(scores,t.test)
tetsts

testsap<-sapply(scores,t.test)# it can process a subset of the t-test values;not everything

#if you want to extract simpler data structures, use sapply
sapply(tetsts,function(t) t$conf.int)


