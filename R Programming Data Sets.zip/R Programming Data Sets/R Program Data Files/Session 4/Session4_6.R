#Data transformations in matrix

#apply function in R

#when the second argument is 1, it refers to the rows
#when the second argument is 2 , it refers to columns


m<-matrix(c(seq(from=-98,to=100,by=2)),nrow=10,ncol=10)
m

apply(m,1,prod)
apply(m,2,sum)

#If you want to write a function such as applying m modulo 3 on the existng matrix
head(m)
apply(m,c(1,2),function(x)x%%3)

