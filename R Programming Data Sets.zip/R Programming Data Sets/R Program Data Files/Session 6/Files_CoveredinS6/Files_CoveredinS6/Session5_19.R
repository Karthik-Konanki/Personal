#EXERCISE
#Concatenate strings "Statistics","is","interesting"
vvv<-paste("Statistics","is","interesting")

#find the length of the concatenated string
length(vvv)
nchar(vvv)
#Extract the first 2 characters from the string: "Inspiration"
substr("Inspiration",1,2)

#Extract the last 2 characters from the string: "Inspiration"
a<-"Inspiration"
substr("Inspiration",nchar(a)-3,nchar(a))

#how do you split the string based on pipeline char :"|name|age|gender|address|"

#Convert the word Parliament to uppercase
x<-toupper("Parliament")

#Convert the word PARLIAMENT to lowercase
x11<- tolower("PARLIAMENT")

#to concatenate the strings "meeku" "peeku" and "cheeku"

lr = paste("meeku","peeku","cheeku")

# in the string formed replace peeku with teeku

lr1 <- sub("peeku","teeku",lr)
lr1

