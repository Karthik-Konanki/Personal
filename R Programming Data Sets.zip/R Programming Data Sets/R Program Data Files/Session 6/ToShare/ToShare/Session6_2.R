abc<- mtcars$mpg
#raise abc to the power of 3

mtcars$mpg1<- abc^3
mtcars$mpg1

#take the ninth root of abc
mtcars$mpg1<- (abc)^(1/9)
mtcars$mpg1

#take the natural logarithm of abc
mtcars$mpg1 <- log(abc)
mtcars$mpg1

#take the base10 logarithm of abc
mtcars$mpg1 <- log10(abc)
mtcars$mpg1

#Raises the constant e to the power of abc
mtcars$mpg1 <- exp(abc)
mtcars$mpg1

#Find the absolute value of abc
mtcars$mpg1<-abs(abc)
mtcars$mpg1

