 numPeople = 10
 sex=sample(c("male","female"),numPeople,replace=T)
 age = sample(14:102, numPeople, replace=T)
 income = sample(20:150, numPeople, replace=T)
 minor = age<18
 
 mode(minor)
 
 population = data.frame(sex=sex, age=age, income=income, minor=minor)
 
 data.frame(a=sex, b=age, c=income, minor=minor)
 
 #SORTING OF DATA FRAMES
 population[order(population$age),]

 #if you want to sort them in ascending order
 population[order(population$age),]
 
 
 #If you want to sort them in descending order
 population[order(-population$age),]
 
 
 #IF ONLY 2 COLUMNS ARE REQUIRED
 population[order(population$age),c(1,2)]
 names(population)
 population$income
 
 