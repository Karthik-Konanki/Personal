set.seed(4680) # for code reproducibility
y<- rnorm(100) # create some dummy data > library(outliers) # load the library
library(outliers)
outlier(y)

 dim(y)<-c(20,5) # convert it to a matrix > head(y,2)# Look at the first 2 rows of the data
y
outlier(y) # Now, check for outliers in the matrix
