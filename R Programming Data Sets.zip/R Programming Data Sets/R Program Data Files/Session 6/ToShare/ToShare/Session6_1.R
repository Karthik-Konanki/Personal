#Gives you today's date
Sys.Date()
#prints a string output
class(Sys.Date())

#How do you convert a string to a date?
as.Date("2010-12-31")

#To convert to an American styled date, we can do this
format(Sys.Date(),format ="%m/%d/%Y")

#convert date to string
format(Sys.Date())
class(format(Sys.Date()))

as.character(Sys.Date())

#Combining date,year and month using ISOdate

ISOdate(2018,2,2)
as.Date(ISOdate(2018,10,12))

as.Date(ISOdate(2012,2,29))


#Calculate Julian date
d<- as.Date("2010-03-15")
as.integer(d)

julian(d)

#Julian date is simply the number of days since a more or less arbitrary starting point
#In the case of R,that starting point is Jan 1,1970,the same starting point as Unix Systems
#So the Julian date for Ja 1,1970 is zero, as shown here:

d1<- (as.Date("2018-06-05"))
as.integer(d1)
julian(d1)

#Extracting parts of date:Parts of date cant be extracted directly as long as it is  a date.
#Hence extraction happens step by step

d<- as.Date("2018-11-05")

p<-as.POSIXlt(d) #to convert date to a list of date objects

p$mon
p$mday
p$year +1900

p$isdst
p$sec
p$min
p$hour
p$wday
p$yday

#creating a sequence of dates
s<- as.Date("2012-01-01")
e<- as.Date("2012-02-01")

#option 1
seq(from = s,to = e,by =1)

#Option 2
seq(from = s,to =e,length.out =7)

#Other options
seq( from =s,by ="month",length.out=12)

seq(from =s,by = "3 months",length.out =12)

seq(from =s,by ="year",length.out = 12)

seq(as.Date("2010-01-29"),by ="month",len =3)