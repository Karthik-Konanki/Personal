#Compute the normalised scores based on "z", "t", "chisq" etc
#Find out observations that lie beyond a given percentile based on a given score.
 set.seed(4680)
x = rnorm(10)
x
scores(x)  # z-scores => (x-mean)/sd

scores(x, type="chisq")  # chi-sq scores => (x - mean(x))^2/var(x)

scores(x, type="t")  # t scores

scores(x, type="chisq", prob=0.9)  # beyond 90th %ile based on chi-sq

scores(x, type="chisq", prob=0.95)  # beyond 95th %ile

scores(x, type="z", prob=0.95)  # beyond 95th %ile based on z-scores

scores(x, type="t", prob=0.95)  # beyond 95th %ile based on t-scores
