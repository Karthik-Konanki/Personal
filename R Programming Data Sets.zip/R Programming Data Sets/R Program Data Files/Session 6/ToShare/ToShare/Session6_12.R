authors <- data.frame(
  name = I(c("Tukey", "Venables", "Tierney", "Ripley", "McNeil","test")),
  nationality = c("US", "Australia", "US", "UK", "Australia","ind"),
  deceased = c("yes", rep("no", 5)))

books <- data.frame(
  name = I(c("tukey", "venables", "tierney",
             "tipley", "ripley", "McNeil", "R Core")),
  title = c("Exploratory Data Analysis",
            "Modern Applied Statistics ...",
            "LISP-STAT",
            "Spatial Statistics", "Stochastic Simulation",
            "Interactive Data Analysis",
            "An Introduction to R"),
  other.author = c(NA, "Ripley", NA, NA, NA, NA,
                   "Venables & Smith"))

merge(authors,books,by ="name")