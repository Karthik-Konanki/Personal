#CONTINGENCY TABLES IN R

set.seed(1)
sample(1:6,10,replace =TRUE)

duplicated(c(1,2,3,1,4))

#CONTINGENCY TABLES IN R

pw<- data.frame(height = c(1:7),plant = c(9,11,6,14,17,19,28),water = c("vulgaris","vulgaris","vulgaris","hibiscus","vulgaris","hibiscus","vulgaris"),level =c("lo","lo","lo","mid","mid","mid","hi"),stringsAsFactors = FALSE)
pw

#Builds a table
table(pw)

#to select 2 columns from the table
table(pw$height,pw$water)

#to visualize the structure of the table
str(pw)

#first 3 rows of the contingency table
pw[1:3,]

#Displays the first 3 rows of the first column
pw[1:3,1]

#displays first 3 rows of the first and second columns
pw[1:3,1:2]

#Displays the column named water
pw[,'water']

#length of the vector object
length(pw)