#VARIABLE CENTERING AND SCALING
library(datasets)
 data(mtcars)
 dim(mtcars)
 str(mtcars)
 cov(mtcars$disp, mtcars$cyl) # check for covariance

 mtcars$disp.scl<-scale(mtcars$disp, center = TRUE, scale = TRUE) 
 mtcars$cyl.scl<- scale(mtcars$cyl, center = TRUE, scale = TRUE) 
 cov(mtcars$disp.scl, mtcars$cyl.scl) # check for covariance in scaled data

 
 #Consider variables qsec and wt and scale them and find the covariance
 
 mtcars$qsec.scl<- scale(mtcars$qsec,center =TRUE,scale =TRUE)
 mtcars$wt.scl<-scale(mtcars$wt,center =TRUE,scale =TRUE)
 cov(mtcars$qsec.scl,mtcars$wt.scl)