#MERGING DATA

authors <- data.frame(
  surname = I(c("Tukey", "Venables", "Tierney", "Ripley", "McNeil","test")),
  nationality = c("US", "Australia", "US", "UK", "Australia","ind"),
  deceased = c("yes", rep("no", 5)))

books <- data.frame(
  name = I(c("tukey", "venables", "tierney",
             "tipley", "ripley", "McNeil", "R Core")),
  title = c("Exploratory Data Analysis",
            "Modern Applied Statistics ...",
            "LISP-STAT",
            "Spatial Statistics", "Stochastic Simulation",
            "Interactive Data Analysis",
            "An Introduction to R"),
  other.author = c(NA, "Ripley", NA, NA, NA, NA,
                   "Venables & Smith"))


#outer join
merge(authors,books,by.x = "surname",by.y= "name",all = TRUE)
merge(books,authors,by.x = "name",by.y ="surname", all = TRUE)

#LEFT JOIN

merge(authors,books,by.x= "surname",by.y ="name",all.x = TRUE)

#RIGHT JOIN
merge(authors,books,by.x ="surname",by.y ="name",all.y =TRUE)



