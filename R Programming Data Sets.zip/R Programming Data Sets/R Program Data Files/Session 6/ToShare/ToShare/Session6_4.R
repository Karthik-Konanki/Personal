library(e1071)
 engine.displ<-skewness(mtcars$disp) 
 engine.displ

 
 #CLASSWORK
 
 #find the skewness of wt
 library(e1071)
 wtskew<- skewness(mtcars$wt)
 wtskew
 
 