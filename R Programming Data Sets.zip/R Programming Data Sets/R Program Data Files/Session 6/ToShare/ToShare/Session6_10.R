#CLASSWORK
mtcars
#sort by mpg

newdata<-mtcars[order(mtcars$mpg),]

#sort by mpg and cyl
newdata1<- mtcars[order(mtcars$mpg,mtcars$cyl),]
newdata1
#sort by mpg(Ascending) and cyl(descending)
newdata2<- mtcars[order(mtcars$mpg,-mtcars$cyl),]
newdata2