#How do you provide names to vectors and extract them using CBR?
 years <- c(1960, 1964, 1976, 1994)
names(years) <- c("Kennedy", "Johnson", "Carter", "Clinton")
years

years["Carter"]
years["Clinton"]
years[c("Carter","Clinton")]

#What do you get when you perform arithmetic operations on vectors of unequal length?
v <-c(11,12,14,15,16)
w<- c(1,2,3,4)
v+w
#Concept of recycling
v <-c(11,12,14,15,16)
w<- c(1,2,3,4,5)

v+w
v-w
v*w
v/w
v%%w
v^w

#Using vector operations with a scalar

ab <- c(1,2,3,4,5,5)
ab*2
ab/2
ab ^0.5

mean(ab)
ab- mean(ab)
log(ab)
sin(ab)


#Question
n<-10
0:n-1
#Precedence 
#Assumes as (0:n)-1



