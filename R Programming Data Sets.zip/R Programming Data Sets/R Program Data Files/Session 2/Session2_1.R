
#Instantiating Variables

#When we have to save a value in a variable, there is no need to declare the variable
x<-3

#When performing simple calculations usng R

x<-4
y<-5
z<- sqrt(x^2 +y^2)
print(z)

#R is a dynamically typed language
x<-5
print(x)
str(x)
x<-"a"
print(x)
str(x)

#Other ways to instantiate variables
x = 3
3->x
x

x1<<-3
#What are the variables that are present in the workspace

#Creating hidden variables
.hid =54
ls(all.names= "TRUE")
ls()
ls()

