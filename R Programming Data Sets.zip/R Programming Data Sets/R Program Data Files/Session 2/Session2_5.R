#Simple Vector operations explained
abbc<- c(1,2,3)
vba <- c(4,5,6)
abbc+vba


abbc<- c(1,2,3)
vba <- c(4,5,6)
abbc*vba

abbc<- c(1,2,3)
vba <- c(4,5,6)
abbc-vba

abbc<- c(1,2,3)
vba <- c(4,5,6)
abbc/vba

abbc<- c(1,2,3)
vba <- c(4,5,6)
abbc%%vba

abbc<- c(1,2,3)
vba <- c(4,5,6)
abbc||vba

abbc<- c(1,2,3)
vba <- c(4,5,6)
abbc && vba

#Basic Statistics on Vectors
x<- c(1,2,3,4,5,6,9,10,11)
mean(x)
median(x)
sd(x)
var(x)

x<-c(1,2,3,4,5,6,7,8)
y<-log(x+1)
cor(x,y)
cov(x,y)

#why data imputation is very important
x<-c(0,1,1,2,3,NA)
mean(x)
sd(x)

#Solution to it
x<-c(0,1,1,2,3,NA)
mean(x,na.rm = TRUE)

sd(x,na.rm =TRUE)









