#Create a simple spreadsheet and try reading that file
#Assign 2 variables in a separate R file ,use source function to call that file
#write the file that was read into a new csv using write function in r