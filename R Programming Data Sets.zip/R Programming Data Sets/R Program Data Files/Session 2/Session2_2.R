#try instantiating 2 variable to solve the equation y = mx +c when x = 5, m = 3, c = 2

m<-3
c<-2
x<-5
y = m*x+ c
print(y)

#Try using these values to solve this simple quadratic equation
a = 4
b = 3
c = -9

x = 8

#solve for y = ax^2 + bx + c

y = (4*(8^2)) + (3*8) + (-9)
print(y)

#Solve for (a/b/c)*( a/(b/c)) *( (a/b)/c)

#where a = 8 b = 4 c = 2
a = 8
b = 4
c = 2

(a/b/c)*( a/(b/c)) *( (a/b)/c)



#Solve for 45 modulo 2
c <-45%%2

