#Workspace and variables
#Removing all variables from your workspace
rm(list = ls())
ls()

#looking for structure of variables
x<-4
ls()
str(x)
y<- "hi"
ls.str()

#To list all the hidden variables 
.hidtest <-4
ls()
ls(all.names="TRUE")

#to delete variables from workspace
xpi<- 2*pi
xpi
rm(xpi)
ls()
xpi

#to delete all variables from workspace
rm(list = ls())
objects()
