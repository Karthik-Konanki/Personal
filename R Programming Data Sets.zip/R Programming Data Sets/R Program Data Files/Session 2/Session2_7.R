#logical operators
a<-3
a ==pi
#test for equality
a!=pi
a<pi
a>pi
a<=pi
a>=pi


#Comparing two vectors
v<- c(3,pi,4)
w<- c(pi,pi,pi)
v ==w
v !=w
v< w
v <= w
v >w
v >=w
 
any(v ==pi) # to verify if any of the values of the vector is equal to pi
all(v ==0) # to verify if all the values of the vector is equal to 0


#SELECTING VECTOR ELEMENTS
#you can use position vector to select any element by their position
#negative indices to exclude elements
# vector of multiple indices to select multiple elements
# Use logical vectors to select elements based on certain condition
#Use names to access named elements

fib <-c(0,2,3,34,5,7,8,9,10,11,12)
fib
fib[1]
fib[2]
fib[10]
fib[2:5] 
#I can also pass a vector of positioning elements
fib[c(1,2,3,4)]

fib[-1]# to remove a particular element from a vector
fib[-(1:3)]

fib<10
fib[fib<10]
fib %%2 == 0

fib[fib %%2 ==0]




