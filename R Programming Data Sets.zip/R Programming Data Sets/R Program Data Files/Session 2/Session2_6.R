#Creating Sequences in R
1:10
0:9
10:100
9:0
-20:-10

#when there is a specific pattern involved in generating sequences,
seq(from =1 ,to=5,by = 2)

seq(from = -10, to = 10, by = 2)
seq(from = 0,to =10,length.out = 5)

seq(from = 0,to =100,length.out = 5)

#creating sequences using rep operator
rep(pi, times = 5)

rep(10,100)

