#Creating a vector


vec1<- c(4,5,6)
vec1
str(vec1)#numeric vector of 3 objects is created now

#Different types of vectors
vec2 <-c(1,12,3,34,45,56,6)
vec3 <-c(1*pi,2*pi,3*pi,4*pi)
vec4 <-c("Everyone","loves","stats")
vec5<- c(TRUE,FALSE,TRUE)
ls.str()

#merging 2 vectors

vec6<-c(8,9,10)
vec7<-c(11,12,13)
c(vec6,vec7)

#VECTOR is homogenous in nature; doesn't support multiple data types ,Suppose if there are multiple datatypes combined,
#R converts one vector format to the other to make them a single datatype
vec8 <-c(1,2,3)
vec9<-c("a","b","c")
c(vec8,vec9)

#Another way to check for datatypes
mode(3.1233)
#numeric
mode("foo")
#character

yy<-c(3.1232,"foo")
mode(yy)


