#Convert a list to vector 
#Why do we do this? More statistical functions work on a numeric vector and they don't work on lists.Hence flattening a list to a vector is necessary
iq.scores<-c(40,50,60,70,20)
mean(iq.scores)

iqscoreslist<-list(40,30,20,80,90)
mean(iqscoreslist)

#When you have a list ,how do you convert it to a vector
mean(unlist(iqscoreslist))

#Removing elements from list based on a particular condition

lstremove<-list(-1,-2,0,1,2,3)
lstremove[lstremove<0]<-NULL
lstremove

lstremove[abs(lstremove)<1]<-NULL
lstremove[unlist(lstremove)<1]<-NULL


#Verify for Nas in the list
lstNa<- list(1,2,4,5,6,7,8,24,56,NA,55)
lstNa[is.na(lstNa)]<-NULL
lstNa



