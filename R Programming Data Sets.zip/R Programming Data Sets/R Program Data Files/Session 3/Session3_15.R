v1<-c(1,3,5,7,9)
v2<-c(0,2,4,6,8)
v3<-c(2,3,5,7,11)
frame<- data.frame(v1,v2,v3)
frame
as.data.frame(frame)
class(frame)


v1<-c(1,3,5,7,9)
v2<-c(0,2,4,6,8)
v3<-c(2,3,5,7,11)
listcreate<-list(v1,v2,v3)
frame_list<-as.data.frame(listcreate)
as.data.frame(frame_list)

head(mtcars)
mtcars[6,4]
mtcars[2,2]
mtcars[4,2]
mtcars[4,2] - mtcars[2,4]
mtcars[3,3]*2
  

mtcars["mpg"]
mtcars[1]
mtcars[1,]

mtcars[c("disp","hp","drat")]
