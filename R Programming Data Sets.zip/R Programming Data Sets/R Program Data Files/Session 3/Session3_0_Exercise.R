#On the vector

cc<- c(10,12,35,10,89,0198)
bb<- c(1,2,4)

#Perform vector arithmetics
#cc +2
#cc -2
#bb *2
#bb/3
#cc+bb
#cc-bb
#cc*bb
#cc/bb

#Get the second element from bb using position vector
#Remove the last element of bb using indexing
#Combine a character vector to bb and see the result

#Extract the first and the last element from cc by building a logical index vector

#add names to bb vector and extract the second element of bb using names(bb)




names(bb)<- c("test","hi","hello")
bb["hi"]

