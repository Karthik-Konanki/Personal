#Create a 3*3 Identity matrix
#Verify if the structure created is matrix or no
#Create a matrix and perform arithmetic operations on them
#a 2*2 matrix with values 1,2,3,4
#Perform matrix multiplication on ab
#Perform transpose function on ab
#Perform inverse on ab
#Get the inverse of the matrix ab
#Verify if the inverse is calculated correctly
#Calculate the eigen value of matrix

#Verify the dimensions of the built matrix
