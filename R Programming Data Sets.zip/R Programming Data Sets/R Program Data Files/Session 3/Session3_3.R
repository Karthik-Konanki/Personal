startup<-list("the","value","of","a","startup","is", "estimated", "by","experts")
startup

numbe<-list(34,56,78,26,20,188,4343,45)
numbe

piCalc <-list("The","value","of","pi","which","is","3.1415","is","a","constant","and","is","used","in","calculating","the","circumference","of","spherical","objects")

piCalc

test<-list();
test[1]<-"this"
test[2]<-"is"
test[3]<-"a"
test[4]<-"test"
test[5]<-"message"

verifylist1<-list()
verifylist1[1]<-"this"
verifylist1[2]<-"is"
verifylist1[3]<-"a"
verifylist1[4]<-NULL
verifylist1[5]<-"test"
verifylist1[6]<-"message"
verifylist1


years1<- list(Independence = 1947,Republic = 1950)
years1

hh<-list(1,4,5,6,8,9)
hh

hh[[1]]
hh[[3]]
hh[4]


listnameSelect<-list(first = 100, second =90,third =80,fourth =70)
listnameSelect$third


likertvalue<-list("StronglyDisagree","Disagree","Neutral","Agree","StronglyAgree")
likertscale<-list(-5,-2,0,2,5)
listlikert<-list(likertvalue,likertscale)
listlikert

