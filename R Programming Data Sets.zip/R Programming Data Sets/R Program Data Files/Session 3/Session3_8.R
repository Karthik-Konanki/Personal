#A company tracks the frequency and traffic of its cab services over the weekdays.CApture the observations and the days when traffic is maximum

cab<-factor(c("Mon","Mon","Tue","Tue","Mon","Thu","Thu","Fri","Fri","Thu"),c("Mon","Tue","Wed","Thu","Fri"))
cab

#A common example of doing statistical tests using factors and with values and ind
freshmen<-c(0.60,0.35,0.44,0.62,0.60)
sophomores<-c(0.70,0.61,0.63,0.87,0.85,0.70,0.64)
juniors<-c(0.76,0.71,0.92,0.87)

comb<-stack(list(fresh =freshmen,soph=sophomores,jrs = juniors))
print(comb)
aov(values~ind,data =comb)

