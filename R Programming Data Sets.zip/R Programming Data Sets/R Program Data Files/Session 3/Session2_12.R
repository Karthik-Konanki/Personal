#to list all the files in a working directory

list.files()


training.raw <- read.csv('F://R//Data_files_excel//PelicanStores1.csv',header=T,na.strings=c(""),stringsAsFactors = TRUE)

head(training.raw,10)
str(training.raw)

training.raw <- read.csv('F:/R/Data_files_excel/PelicanStores1.csv',header=T,na.strings=c(""),stringsAsFactors = TRUE)

head(training.raw)

training.raw <- read.csv('F:\\R\\Data_files_excel\\PelicanStores1.csv',header=T,na.strings=c(""),stringsAsFactors = TRUE)

head(training.raw)

#Doesnt work-> One backslash doesn't work
training.raw <- read.csv('F:\R\Data_files_excel\PelicanStores1.csv',header=T,na.strings=c(""),stringsAsFactors = TRUE)

head(training.raw)

head(training.raw)
str(training.raw)

#reading a text file is simple
readd<-read.csv("F:\\R\\Data_files_excel\\NewPdt.txt")
head(readd)

#reading a xls file 

library(xlsx)
#require(xlsx)
require(gdata)

library(gdata)
training.ra1w <- read.xlsx("D:/R/R Programming Data Sets-20201114T054118Z-001/R Programming Data Sets/Session 3/PelicanStores.xlsx", "Data",header = T)

head(training.ra1w)

getwd();
setwd("D:/R/Excercise")
getwd()
write.csv(read,file ="Session23.csv",row.names = T)

library(XML)
library(httr)
tables<-GET("http://en.wikipedia.org/wiki/World_population")
tables<- readHTMLTable(rawToChar(tables$content))
head(tables)

install.packages("sqldf")
#reading data using sql queries
library(proto)
library(gsubfn)
library(RSQLite)
library(sqldf)
titanic2<-as.data.frame(Titanic);
fedf<- sqldf("select * from titanic2");
head(fedf)
print(Titanic)
head(Titanic)
data("Titanic")
View(Titanic)
View(iris)
head(iris)
tail(iris)

