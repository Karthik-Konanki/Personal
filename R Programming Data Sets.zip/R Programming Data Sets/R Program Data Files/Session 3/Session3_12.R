n<- 3
tt<-diag(nrow = n,ncol = n)
is.matrix(tt)

ab<- matrix(c(1,2,3,4),2,2,byrow = TRUE)

#Perform matrix operations on ab
ab+ab
ab-ab
ab*ab
ab/ab

ab%*%ab

t(ab)
solve(ab)

solve(ab)%*%ab

eigen(ab)


dia<- diag(nrow =4 , ncol =4)
dim(dia)
nrow(dia)
ncol(dia)