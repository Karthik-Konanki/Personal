#Operations on Lists
#1. Creating a list

x = 4
y = 5
z = 6

alist<- list(x,y,z)

#2.Creating a numeric list

listNum<- list(1,2,3,4)
listNum
listNum2<- list(1.25,2.50,3.75,5)
listNum2

#3.Creating a character list
listChar<-list("a","b","c")
listChar
listChar1<-list("hello","hi","hey")
listChar1

#4.The major differentiation between list and vectors is that while vectors are homogenous, lists are heterogenous

listyears<-list(1996,1997,1998,2000)
listCities<-list("Kolkata","chennai","bangalore","hyderabad")
listCombine<-list(listyears,listCities)
listCombine

#5. Another way of creating a list is to create an empty list and then to populate it
listcreate <-list()
listcreate[1] =1
listcreate[2] ="avfefe"
listcreate[3] = 343
listcreate[4]= "vefe"
listcreate

#6. When there is no value for an intermediate index, it becomes null
listcreate1 <-list()
listcreate[1] = 1
listcreate1[2] ="3434"
listcreate1[4] = "efefe"
listcreate1[6] ="wewrew"
listcreate1

#7.Providing names to a list
listnames<-list(mid = 0.5,left = 0.3,right =0.6)
listnames

listnames1<-list(r =3, g = 35,h = 45)
listnames1



#Selecting list elements by position
pos<- list(1,3,4,5,7,8)
pos

a<- pos[[1]]

a

class(a) #element

#Selecting elements  by using names
abc<-list(a =1, b =2, c =4,d =6)
abc$a
abc$d
abc["c"]


#Creating a name value association list

values<-pnorm(-2:2)
names<-c("far.left","left","mid","right","far.right")
values[2]
names[2]
listComplete<-list(names,values)
listComplete

#Removing an element from the list
abc<-list(a =1,b=2,c=4,d=6)
abc$a

abc[["d"]]<-NULL
abc













