#how do you convert this list to a vector
abc <-list(26,56,47,36,46,49)
#Also find the mean of this vector

#Clean the data and verify for NAs in list
ls<-list(1,2,4,5,6,7,9,10,11,12,15,NA,12)

