abc1<-unlist(abc)
mean(abc1)

ls<-list(1,2,4,5,6,7,9,10,11,12,15,NA,12)
ls[is.na(ls)]<-NULL
ls