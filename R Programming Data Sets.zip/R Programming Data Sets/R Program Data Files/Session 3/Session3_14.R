#1.Create a data frame with vectors v1 holding first 5 odd numbers, v2 holding first 5 even numbers and v3 holding first 5 prime numbers
#2.Merge the vectors onto a list and then convert the list to a data frame
#3.Load the package mtcars
head(mtcars)
?mtcars

mtcars[1,2]
mtcars["Mazda RX4","cyl"]
nrow(mtcars)
ncol(mtcars)
help(mtcars)
#4.Extract the following and print the values of these :

#i=6;j=4
#i = 2,j =2
#i =4 ,j = 2
#i[4,2]- j[2,4]
#i[3,3] *2

#5.extract the column mpg from the dataset mtcars

#6. Extract the first column from mtcars
#7. Extract the first row from mtcars

# Extract columns disp hp drat from mtcars

#FURTHER ROW SLICING

mtcars[12,]
mtcars[c(1,4,6)]
mtcars["Volvo 142E",]

#Logical indexing
L =mtcars$am ==0
L

mtcars[L,]
mtcars[L,]$mpg

mean(mtcars[L,]$mpg)
