#to list all the files in a working directory

list.files()


training.raw <- read.csv('D:/R/R Programming Data Sets-20201114T054118Z-001/R Programming Data Sets/Session 2/Session2_ToShare/Session2_ToShare//PelicanStores1.csv',header=T,na.strings=c(""),stringsAsFactors = TRUE)

head(training.raw)

training.raw <- read.csv('F:/R/Data_files_excel/PelicanStores1.csv',header=T,na.strings=c(""),stringsAsFactors = TRUE)

head(training.raw)

training.raw <- read.csv('F:\\R\\Data_files_excel\\PelicanStores1.csv',header=T,na.strings=c(""),stringsAsFactors = TRUE)

head(training.raw)

#Doesnt work-> One backslash doesn't work
training.raw <- read.csv('F:\R\Data_files_excel\PelicanStores1.csv',header=T,na.strings=c(""),stringsAsFactors = TRUE)

head(training.raw)

head(training.raw)
str(training.raw)

#reading a text file is simple
readd<-read.csv("F:\\R\\Data_files_excel\\NewPdt.txt")
head(readd)

write.csv(readd,file ="Session2.csv",row.names = T)
