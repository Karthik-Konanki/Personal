#How do you define functions in R


test<-function(x) sqrt(x)
test(4)

cv<-function(x) sd(x)/mean(x)
cv(1:10)

	ab<- function(x) mean(x) + median(x)
	dc<- c(1,2,3,4)
	ab(dc)


gcd<- function(a,b) {if(b==0) return(a) else return(gcd(b,a%%b))} 
gcd(45,5)
gcd(80,16)
gcd(80,0)
gcd(43,5)
gcd(120,5)
gcd(120,120)

