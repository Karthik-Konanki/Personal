#data entered from keyboard
xm<- c(1,2,3,4,45)

#data entered by creating a data frame object and inputting data
scores<-data.frame()
scores<-edit(c(1,2,3,4,5))


#PRINTING FEWER DIGITS/ PROCESSING INPUT DATA
#to lower the number of digits and perform some data cleaning operations
q<- seq(from =0, to = 3,by =0.5)
tbl <-data.frame(Quant =q,Lower = pnorm(-q),Upper = pnorm(q))
tbl

print(tbl,digits=2)

print(pi,digits =4)

#If I have to write the output in a file outside the R console , then 
getwd();
#setwd("F:/R")
answer =5
cat("The answer is", answer, "\n", file="test.txt")

# to write values outside R console
sink("example.txt")
m<-123
n<-23
p<-43
print(m)
print(n)
print(p)
m
sink()
m

#Source function
source("print.R")

print(xver)
xver
yver

#detach(print.R)


