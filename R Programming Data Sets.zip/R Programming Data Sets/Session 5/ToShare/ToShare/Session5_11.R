#Functions in R
#Functions bring in modularity and are helpful when complicated tasks are to be accomplished

#func_name <- function (argument) {
#  statement
#}

pow <- function(x, y) {
  # function to print x raised to the power y
  result <- x^y
  print(paste(x,"raised to the power", y, "is", result))
}

pow(3,2)  
pow(8,2)

#We can assign default values to arguments in a function in R.
pow <- function(x, y = 2) {
  # function to print x raised to the power y
  result <- x^y
  print(paste(x,"raised to the power", y, "is", result))
}

pow(3)
pow(5)
pow(7)
