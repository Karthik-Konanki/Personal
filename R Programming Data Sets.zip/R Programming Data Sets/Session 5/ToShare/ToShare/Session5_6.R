#EXPLANATION OF WHILE LOOP
#TEST EXPRESSION IS EVALUATED FIRST AND IF ITS TRUE THEN THE STATEMENT IS EXECUTED
#This is repeated each time until test_expression evaluates to FALSE, in which case, the loop exits.
while (test_expression)
{
  statement
}

#example 1
i <- 1
while (i < 6) {
  print(i)
  i = i+1
}

#Amstrong number is where the number is equal to the sum of cubes of its own digits
#eg 370 = 343 + 27 = 7^3 + 3^3 -> 0^3 + 370/10 = 37 -> 37[37%%10] -> 7


# take input from the user
num = as.integer(readline(prompt="Enter a number: "))
# initialize sum
sum = 0
# find the sum of the cube of each digit
temp = num
while(temp > 0) {
  digit = temp %% 10
  sum = sum + (digit ^ 3)
  temp = floor(temp / 10)
}
# display the result
if(num == sum) {
  print(paste(num, "is an Armstrong number"))
} else {
  print(paste(num, "is not an Armstrong number"))
}



