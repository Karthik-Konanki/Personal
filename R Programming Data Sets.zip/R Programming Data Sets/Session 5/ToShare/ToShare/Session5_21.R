#Date functions in R

#Gives you today's date
Sys.Date()

#how do you convert a string to date
as.Date("2010-12-31")


#To convert date to an American styled date, we can do this
format(Sys.Date(),format = "%m/%d/%Y")

#Convert date to string
format(Sys.Date())
class(format(Sys.Date()))

as.character(Sys.Date())

#Combining date ,month and year using ISODate

ISOdate(2018,2,2)
as.Date(ISOdate(2018,10,12))

#Calculating Julian Date
d<- as.Date("2010-03-15")
as.integer(d) #

julian(d) 


d1<- as.Date("2018-06-06")
as.integer(d1)
julian(d1)
?julian
