#RECURSIVE FUNCTIONS IN R
#Recursive function to find factorial
x<-4
recursive.factorial<- function(x) {
  if(x==0) return(1)
  else return(x*recursive.factorial(x-1))
}
recursive.factorial(4)

#Program to convert decimal number into binary number using recursive function
convert_to_binary <- function(n) {
  if(n > 1) {
    convert_to_binary(as.integer(n/2))
  }
  cat(n %% 2)
}

convert_to_binary(52)

convert_to_binary(45)






#       Q     R

#45/2   22    1

#22/2   11    0

#11/2   5     1

#5/2    2     1

#2/2    1     0

#--------------------

#52/2   26    0

#26/2   13    0

#13/2    6    1

#6/2     3    0

#3/2     1    1