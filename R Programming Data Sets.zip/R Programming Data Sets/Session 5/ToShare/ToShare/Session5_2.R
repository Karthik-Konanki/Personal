#Find if the given number is equal to 5
x<- -5
if(x==5){print("Input equal to 5")}else {print("Input not equal to 5")}


#Find if 6 is divisible by 2
x<-6
if(x%%6==0){print("6 is divisible by2")}else {print("6 is not divisible by 2")}

#Find if 3 is greater than or equal to zero

x<- 4
if (x==0){print("x is equal to 0")}else if (x>0){print("x is greater than 0")}else {print("x is lesser than 0")}

