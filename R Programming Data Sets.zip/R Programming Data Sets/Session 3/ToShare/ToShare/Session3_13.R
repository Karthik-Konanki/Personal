#1.DATA FRAMES

v1<-c(1,3,4,5,6,7)
v2<-c(2,4,6,8,10,12)
v3<-c(5,10,15,20,25,30)
#f1<-factor(c(AM,PM,PM,AM,AM,PM),c(AM,PM))
#f2<- factor(c(T,F,F,T,T,F),c(T,F))

dfrm<-data.frame(Col1 = v1,col2 = v2,col3 = v3)
dfrm

#2.Creating data frames from list
pred1<- c(-2,-1,0)
pred2<- c(0,1,2)
pred3<- c(2,-2,1)
lst<-list(pred1,pred2,pred3)
lst1<-list(a=pred1,b=pred2,c=pred3)
lst
as.data.frame(lst)
dat<-as.data.frame(lst1)
str(dat)

#3.Another example
n = c(2,3,5)
s = c("aa","bb","cc")
b = c(TRUE,FALSE,TRUE)
df = data.frame(n,s,b)
df

df[[2]] #Slicing the second column from the dataframe

#Retrieving the same column by using name
df[["s"]]

df$s

df
df[1]
df["b"]

