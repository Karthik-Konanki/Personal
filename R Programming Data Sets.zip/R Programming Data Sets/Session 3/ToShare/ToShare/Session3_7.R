#FACTORS
#Factors are categorical variables and each distinct value is called a level 
f<-factor(c("Win","Win","lose","lose","Tie","Tie"))
f
class(f)

f1<-factor(c("Mon","Tue","Tue","Tue","Wed","Wed","Wed","Thu","Thu","Thu","Fri","Fri","Fri"),c("Mon","Tue","Wed","Thu","Fri"))
f1
str(f1)


f2<-factor(c("Mon","Tue","Tue","Tue","Wed","Wed","Wed","Thu","Thu","Thu","Fri","Fri","Fre"),c("Mon","Tue","Wed","Thu","Fri"))
f2

f3<-list(f1, "Mon", "Tue", "Wed")
f3
