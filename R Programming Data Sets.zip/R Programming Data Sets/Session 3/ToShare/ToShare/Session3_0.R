#Other vector operations
#Combining 2 vectors

n <-c (2,3,5)
b<- c("aa","bb","cc")
s<- c(n,b)
s

#Vector arithmetics
a = c(1,3,5,7)
b = c(2,4,8,10)

5*a

a+b

a-b
a/b
a*b

#RECYCLING

a<- c (1,3,5)
b<- c(1,4,6,7,8,9,10,11,45,9)
a+b

#Vector indexing
s<- c("a","b","c","d","e")
s[3]

#Vector negative indexing- for removal
s[-2]

#Vector out of range index
s[100]

#Numeric index vector

#By providing numerical positions, sub-vectors can be sliced out of parent vectors

s = c("aa","bb","cc","dd","eee")
s[c(1,4)]

#Even duplicate numerical indices are possible in R
s[c(1,1,1)]

#Reversed numerical indices
s[c(3,2,1)]

#Range Index
s[c(1:3)]

#Logical index vector

s <- c("aa","bb","cc","dd","ee")
logic<- c(TRUE,TRUE,FALSE,FALSE,TRUE)
s[logic]

#Instead of writing two lines, it can be abbreviated to one line as 
s[c(TRUE,TRUE,FALSE,FALSE,TRUE)]

#VECTOR NAMES

v = c("Merry","Christmas")
v

names(v) = c("Wishes","2018")

v

v["Wishes"]
v[c("2018","Wishes")]


