#Create a character list with values "the","value","of","a","startup","is", "estimated", "by","experts"
#Create a numeric list with values 34,56,78,26,20,188,4343,,45
#Create a list with values: "The value of pi which is 3.1415 is a constant and is used in calculating the circumference of spherical objects
#Create an empty list named verifylist and populate it using values "this","is","a","test","message"
#Create the same empty list named verifylist1 and populate it using values "this","is","a"," "[null],"message"
#Create a list with values 1947,1950 and provide names "Independence","Republic"
#Illustrate an example of using position vector on a list
#Select an element from a list after providing a name
#create a five point likert scale with names and values association : Hint : Strongly Disagree, Disagree, Neutral, Agree, Strongly Agree : -5 -2 0 2 5

test<-list()
test



hh<-list(1,2,5,9,6,8,7)
hh
w<-hh[[4]]
x<-hh[4]

w
x

class(w)
class(x)


likert_scale<-list(Strongly_Disagree = -5, Disagree = -2, Neutral = 0, Agree = 2, Strongly_Agree = 5)
likert_scale
