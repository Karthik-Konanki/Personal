#MATRIX RELATED FUNCTIONS

#1. Capturing the data in a vector and then converting into a vector
vect<- c(1,3,4,5,6,6,7,6)
matrix(vect,4,2)
matr<-matrix(vect,4,2)
matrix(vect,2,4)

matrix(vect,4,4)
#Ex2
theData<- c(1.1,1.2,2.1,2.2,3.1,3.2)
mat<- matrix(theData,2,3)
mat
#the arguments passed are the vector, rows, columns in the same order
matrix(0,2,3)
matrix(NA,2,3)
matrix(c(1.1,1.3,1.5,1.7,1.9,2.1),2,3,byrow = TRUE)

v<-c(1.1,1.2,1.3,1.4,1.5,1.6)
dim(v)<-c(2,3)
v

lst<-list(matr,vect)

lst

#Matrix:

#Uni-dimensional, Homogeneous in nature, numeric vectors


#arithmetic
#Algebraic
#Transpose
#inverse
#identity
#diagonal
#determinant

