#Lets create a matrix
m<- matrix(c(1,2,3,4),2,2,byrow = TRUE)
m

is.matrix(m)

as.matrix(data.frame(x = c(1,0),y = c(0,1)))

#Diagonal matrix -> All the diagonal elements in the matrix are equal
m<- diag(nrow =2, ncol =2)
m

#Identity matrix -> All diagonal elements in the matrix are 1
n<- 10
diag(nrow = n,ncol = n)

#Matrix Algebra
m<- matrix(c(0,2,1,0),nrow = 2, ncol = 2,byrow = TRUE)
m+m
m-m
m*m
m/m

#matrix Multiplication
m%*%m

#Calculate the transpose of matrix m
t(m)

#To calculate the inverse of matrix m
solve(m)

# AA^-1 is always 1 which is nothing but the diagonal matrix
solve(m)%*%m


eigen(m)

m<- diag(nrow =2 , ncol =2)
dim(m)
nrow(m)
ncol(m)

#Selecting a row or column from a matrix
vec<- m[1,]
vec
vec<-m[,3]
vec


