#CORRELOGRAM
#Most of the times, we need to look at the correlation numbers of 
#multiple continuous variables, in those cases, use a Corrplot
library(ggplot2)
library(ggcorrplot)
#Correlations between multiple continuous variables can be seen using Corr Plot
# Correlation matrix
data(mtcars)
corr <- round(cor(mtcars), 1)

# Plot
ggcorrplot(corr, hc.order = TRUE, 
           type = "lower", 
           lab = TRUE, 
           lab_size = 3, 
           method="circle", 
           colors = c("tomato2", "white", "springgreen3"), 
           title="Correlogram of mtcars", 
           ggtheme=theme_bw)

