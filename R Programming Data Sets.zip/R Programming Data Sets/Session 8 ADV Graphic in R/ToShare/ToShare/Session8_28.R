library(ggplot2)
library(ggfortify)
#has autoplot function which automatically plots time series graphs
theme_set(theme_classic())

# Plot 
autoplot(AirPassengers) + 
  labs(title="AirPassengers") + 
  theme(plot.title = element_text(hjust=0.5))

