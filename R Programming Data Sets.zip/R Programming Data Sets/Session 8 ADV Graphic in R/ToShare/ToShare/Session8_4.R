#An alternative to overcome the problem of data points overlap and thereby seeing reduced plotting is to use counts chart
# load package and data
#geom_count() is used to plot counts chart
#count chart represents the points overlap and bigger the size of the circle, the more is the overlap
library(ggplot2)
data(mpg, package="ggplot2")
# mpg <- read.csv("http://goo.gl/uEeRGu")

# Scatterplot
theme_set(theme_bw())  # pre-set the bw theme.
g <- ggplot(mpg, aes(cty, hwy))
g + geom_count(col="tomato3", show.legend=T) +
  labs(subtitle="mpg: city vs highway mileage", 
       y="hwy", 
       x="cty", 
       title="Counts Plot")

#The more the number of points around the same location,bigger is the size of the circle

