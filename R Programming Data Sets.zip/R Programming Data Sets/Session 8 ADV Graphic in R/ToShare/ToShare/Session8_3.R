#Let us look at a new data set now
#Let us use the mpg dataset to plot the city mileage against the highway mileage
library(ggplot2)
data(mpg, package="ggplot2") # alternate source: "http://goo.gl/uEeRGu")
theme_set(theme_bw())  # pre-set the bw theme.

g <- ggplot(mpg, aes(cty, hwy))

# Scatterplot
g + geom_point() + 
  geom_smooth(method="lm", se=F) +
  labs(subtitle="mpg: city vs highway mileage", 
       y="hwy", 
       x="cty", 
       title="Scatterplot with overlapping points", 
       caption="Source: midwest")


#Though we get a neat,clean scatterplot with strong correlation here ,is there anything thats missing as a part of this plot?

dim(mpg)
#there are 234 rows but not all are plotted.To fix this, one should use Jitterplot

#What is a jitterplot?
#its similar to scatterplot but all points to be likely plotted

# load package and data
#geom_jitter is used to plot jitter plot
library(ggplot2)
data(mpg, package="ggplot2")
# mpg <- read.csv("http://goo.gl/uEeRGu")

# Scatterplot
theme_set(theme_bw())  # pre-set the bw theme.
g <- ggplot(mpg, aes(cty, hwy))
g + geom_jitter(width = .5, size=1) +
  labs(subtitle="mpg: city vs highway mileage", 
       y="hwy", 
       x="cty", 
       title="Jittered Points")

